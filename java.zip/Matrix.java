import java.util.Scanner;
import java.io.*;


public class Matrix
{
public static void main(String args[])
{
int a,b,c,d;
Scanner sc= new Scanner(System.in);
System.out.println( "Enter the no of rows and columns : ");
a= sc.nextInt();
b= sc.nextInt();
int First[][]=new int[a][b];
int Second[][]=new int[a][b];
int sum[][] = new int[a][b];



System.out.println(" enter the valves of First matrix : ");

for(c=0;c<a;c++)
for(d=0;d<b;d++)
 First[c][d]= sc.nextInt();

System.out.println(" enter the valve of second matrix : ");
for(c=0;c<a;c++)
for(d=0;d<b;d++)
Second[c][d]= sc.nextInt();


 for(c=0;c<a;c++)
 for(d=0;d<b;d++)
sum[c][d]= First[c][d] + Second[c][d];

System.out.println(" sum of the matrix : ");
for(c=0;c<a;c++)
{
for(d=0;d<b;d++)
System.out.print(sum[c][d]+"\t");
System.out.println();

}
}

}