import java.io.*;
import java.util.*;
public class Fib
{
public static void main(String args[])
{
int index = 0;
int next = 1;
int incr = 0;

System.out.print( index + ", " + next );

for ( int i = index; i < 15; ++i )
{
incr = index + next;
System.out.print(", " + incr );
index = next;
next = incr;
}
}
}
