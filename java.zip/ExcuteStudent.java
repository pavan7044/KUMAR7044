import java.io.*;
import java.util.*;
class Student1
{
int rollno;
int marks;
String name;

void setstudent(int r,int m,String n);
{
rollno=r;
name=n;
marks=m;
}
void getStudent()
{
System.out.println(" rollno: " +rollno);

System.out.println(" name : " +name);


System.out.println(" marks : " +marks);
}
}
class ExcuteStudent
{
public static void main(String args[])
{
Student s1= new Student();
Student s2= new Student();

s1.setStudent(101,"raju",500);
s2.setStudent(102,"radha",550);

s1.getStudent();
s2.getStudent();
}
}

























class ExcuteStudent
{
public static void main(String[] args)
{
int rollno,marks;
String name;
Student s1=new Student();
Student s2=new Student();
s1.rollno=101;
s1.name="ramu";
s1.marks=500;
s2.rollno=102;
s2.name="radha";
s2.marks=550;


System.out.println(rollno : "+s1.rollno");
System.out.println(name :"+s2.name");
System.out.println( rollno : "+s2.rollno");
System.out.println( Marks :"+s1.marks");
System.out.println( Marks : "+s2.marks");
System.out.println( name :"+s1.name");
System.out.println(s1 address  : "+s1.address");
System.out.println( s2 address :"+s2.address");
}
}
