import java.io.*;
import java.util.*;

class Star
{
public static void main(String args[])
{
int i;



for(i=0;i<=10;i++)

i=i+1;
System.out.println(" " +i);
}
}
