class Operations

{

void hi()
{
System.out.println(" welcome");
}


float avg(int a, int b, int c)
{

return (float) (a+b+c)%3;

}
float pi()
{
return(float) 3.14;
}
} 
