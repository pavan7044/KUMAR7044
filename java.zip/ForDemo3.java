import java.io.*;
import java.util.Scanner;

public class ForDemo3
{

public static void main(String args[])
{
int []b =new int[5];
b[0]=10;
b[1]=20;
b[2]=30;
b[3]=40;
b[4]=50;
for(int i=0;i<=5;i++)
{
System.out.println(" b(i) " + b[i]);
}
}
}
