class Test
{
public static void main(String args[])
{
int mn;
mn= Integer.parseInt(args[0]);
if(mn==2 || mn==3 || mn==4 || mn==5)
{
System.out.println("summer");
}
else if(mn==6 || mn==7 || mn==8 || mn==9)
{
System.out.println("winter");
}
else if (mn==10 || mn==11 || mn==12 || mn==1)
{
System.out.println("rainy");
}
else
{
System.out.println("please enter a valid month number");
}
}
}





