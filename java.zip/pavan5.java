class Pavan5
{
public static void main(String args[])
{
int x;

for(x=0;x<100;x++)
{
System.out.println ("pavan kumar ");


}
}
}






