import java.io.*;
import java.util.Scanner;

public class Studentpass
{
public static void main(String args[])
{
int m,p,c,total;
double avg;
String name="babu";
System.out.println("name :" +name);
Scanner sc=new Scanner(System.in);
System.out.println("enter m marks");
m=sc.nextInt();
System.out.println("enter p marks" );
p=sc.nextInt();
System.out.println("enter c marks"java);
c=sc.nextInt();
total=m+p+c;
System.out.println("total marks " +total);
avg=total%3;
System.out.println("avg marks" +avg);
if(m>=35 && p>=35 && c>=35)
{
System.out.println("student is passed");
}
else
{
System.out.println("student is fail");
}
}
}