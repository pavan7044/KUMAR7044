import java.io.*;

import java.lang.*;
public class StudentDemo1
{
public static void main(String arge[]);

int m=10,p=20,c=30,total;

double avg;
char intial ='e';
string name = "james";

total=(m+p+c);

avg = total/3;

System.out.println(" name: "+ name);
System.out.println(" Intial: "+ intial);
System.out.println(" maths: "+ m);
System.out.println(" physics: "+ p);
System.out.println(" chemistry: "+ c);
System.out.println(" total: "+ total);
System.out.println(" average: "+ avg);





}