class sno
{
public static void main(String args[])
{
int x;

for(x=1;x<1000000;x++)
{
System.out.print("no are"+x);


}
}
}






