import java.io.*;
import java.util.Scanner;

public class ForDemo4
{

public static void main(String args[])
{
int[] b=new int[5];
Scanner sc= new Scanner(System.in);
System.out.println("enter the 5 valves");
for(int i=0;i<=4;i++)
{
b[i]=sc.nextInt();
}
System.out.println("array b data :");

for(int i=0;i<=4;i++)
{
System.out.println(" b[i]" +b[i]);
}
}
}