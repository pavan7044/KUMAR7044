import java.io.*;
import java.util.*;

public class Program {
    public static void main(String[] args) 
{
	// Create 2-dimensional array.
	int[][] values = new int[9][9];

	// Assign three elements in it.
	values[0][0] = 1;
	values[0][1] = 2;
	values[3][0] = 3;
	values[3][1] = 3;	
	values[3][2] = 3;
	values[3][3] = 3;
	values[2][2] = 3;
	values[3][0] = 3;
	values[1][2] = 3;
	// Loop over top-level arrays.
	for (int i = 0; i < values.length; i++) {

	    // Loop and display sub-arrays.
	    int[] sub = values[i];
	    for (int x = 0; x < sub.length; x++) {
		System.out.print(sub[x] + " ");
	    }
	    System.out.println();
	}
    }
}