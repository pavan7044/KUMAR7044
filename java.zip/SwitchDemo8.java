import java.io.*;
import java.util.Scanner;

public class SwitchDemo8
{
public static void main(String args[])
{

int a;

Scanner sc=new Scanner(System.in);
System.out.println("enter a valve");
a=sc.nextInt();
if(a>10)
{
System.out.println("i="+a);
}


}
}