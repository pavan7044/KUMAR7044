import java.io.*;
import java.util.Scanner;

public class SwitchDemo7
{
public static void main(String args[])
{
int i;
Scanner sc=new Scanner(System.in);
i=sc.nextInt();
do
{
System.out.println("i="+i);
}
while(i<5);

}
}