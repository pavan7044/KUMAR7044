import java.io.*;
import java.util.Scanner;

public class SwitchDemo
{
public static void main(String args[])
{
char a; 
Scanner sc= new Scanner(System.in);
System.out.println("enter a char ");
a=sc.next().charAt(0);
switch(a)
{
case 'a':
System.out.println("it is vowel");
break;
case 'e':
System.out.println("it is vowel");
break;
case 'i':
System.out.println("it is vowel");
case 'o':
System.out.println("it is vowel");
break;
case 'u':
System.out.println("it is vowel");
break;
default:
System.out.println("it is  not avowel");
}
}
}
