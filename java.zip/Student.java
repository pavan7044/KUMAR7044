

public class Student 
{

	public static void main(String[] args) 
	{
	
		//int marks,rollno,s1.roll no,s1.marks;
		//String s1.name;
		Student s1= new Student();
		Student s2=new Student();
		System.out.println(" roll no: " +s1.rollno);
		System.out.println("name : " +s1.name);
		System.out.println(" maths : " +s1.marks);
		s1.roll no=101;
		s1.name="pavan";
		s1.marks=500;
		s2.name="radha";
		s2.roll no=102;
		s2.marks=550;
		System.out.println(" roll no: " +s1.rollno);
		System.out.println("name : " +s1.name);
		
		System.out.println(" marks : " +s1.marks);
		System.out.println(" roll no: " +s2.rollno);
		System.out.println("name : " +s2.name);
		System.out.println(" maths : " +s2.marks);
		
		/*System.out.println(" s1 address :" +s1);
		System.out.println("s2 address :"+s2);*/
		
		
	}

}