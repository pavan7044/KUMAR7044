import java.io.*;

import java.lang.*;
public class IfDemo
{
	public static void main(String args[])
	{
		int a=10,b=11;
		if(a>b)
		{
			System.out.println("a>b");
		}
		else
		{
			System.out.println("b>a");
		}
			
	}
}