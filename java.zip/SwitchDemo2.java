import java.io.*;
import java.util.Scanner;

public class SwitchDemo2
{
public static void main(String args[])
{
int a; 
Scanner sc= new Scanner(System.in);
System.out.println("enter a digit ");
a=sc.nextInt();
Switch(a);
{
case 0:
System.out.println("it is zero");
break;
case 1:
System.out.println("it is one");
break;
case 2:
System.out.println("it is two");
case 3:
System.out.println("it is three");
break;
case 4:
System.out.println("it is four");
break;
default:
System.out.println("it is  not avowel");
}
}
}