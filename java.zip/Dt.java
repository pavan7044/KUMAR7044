import java.io.*;
import java.util.*;


class Dt
{
public static void main(String args[])
{
int n,m;
for(n=0;n>=0;n++)
{
for(m=1;m==n;m++)
{
System.out.println( m);
}
System.out.print("\n");
}

}
}
