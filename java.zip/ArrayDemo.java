import java.util.*;
import java.io.*;
public class ArrayDemo
{
public static void main(String args[])
{
int[] a=new int[5];
Scanner sc=new Scanner(System.in);
System.out.println("enter the valves");
for(int i=0;i<=4;i++)
{
a[i]=sc.nextInt();
}
System.out.println(" Array A data: ");
for(int i=0;i<=5;i++)
{
System.out.println( " a[+ i] "+a[i] );

}

}

}

