import java.io.*;
import java.util.Scanner;

public class ForDemo1
{


public static void main(String args[])
{
int a,b,c,sum;
Scanner sc= new Scanner(System.in);
System.out.println("enter a valve");
a=sc.nextInt();
System.out.println("enter b valve");
b=sc.nextInt();
System.out.println("enter c valve");
c=sc.nextInt();

sum = (a+b+c);
System.out.println(" sum = " +sum);
}
}


