import java.io.*;
import java.util.Scanner;

public class Name
{

public static void main(String args[])
{
char[] name= new char[11];
name[0]='p';
name[1]='a';

name[2]='v';

name[3]='a';

name[4]='n';
name[5]=' ';
name[6]='k';
name[7]='u';
name[8]='m';
name[9]='a';
name[10]='r';
for(char k : name)
{
System.out.print(k);
}


}
}