
class C1
{
public static void main(string [] args);
int num;
System.out.println("\nenter a number");
num=sc.nextInt();
if(num==1)
System.out.println("\n  MONDAY ");
else if(num==2)
System.out.println("\n  TUESDAY ");
else if(num==3)
System.out.println("\n WEDNESDAY");
else if(num==4)
System.out.println("\n THURSDAY");
else if(num==5)
System.out.println("\n  FRIDAY ");
else if(num==6)
System.out.println("\n SATURDAY ");
else if(num==7)
System.out.println("\n SATURDAY ");
}