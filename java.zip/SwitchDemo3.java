import java.io.*;
import java.util.Scanner;

public class SwitchDemo3
{
public static void main(String args[])
{
int i; 
for(i=0;i<6;i++)
{
System.out.println("i="+i);
}
}
}