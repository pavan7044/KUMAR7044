class Monthno
{
public static void main(String args[])
{
int mn;
mn=Integer.parseInt(args [0]);
switch(mn)
{
case 1:
System.out.println("jan.....");
break;
case 2:
System.out.println("feb.....");
break;
case 3:
System.out.println("mar.....");
break;
case 4:
System.out.println("apr.....");
break;
case 5:
System.out.println("may.....");
break;
case 6:
System.out.println("jun.....");
break;
case 7:
System.out.println("feb.....");
break;
case 8:
System.out.println("feb.....");
break;
case 9:
System.out.println("feb.....");
break;
case 10:
System.out.println("feb.....");
break;
case 11:
System.out.println("feb.....");
break;
case 12:
System.out.println("feb.....");
break;
default:
System.out.println("feb.....");
break;
}
}
}






