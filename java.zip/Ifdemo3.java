import java.io.*;
import java.util.Scanner;

public class Ifdemo3
{
public static void main(String args[])
{
int a,b;
Scanner sc=new Scanner(System.in);
System.out.println("enter a value");
a=sc.nextInt();
System.out.println("enter b valve");
b=sc.nextInt();
if(a>b)
{
System.out.println("a is greatest");
}
else
{
System.out.println("b is greatest");
}
}
}