import java.io.*;
import java.util.Scanner;

public class SwitchDemo5
{
public static void main(String args[])
{
int i; 
while(i>=1)
{
System.out.println("i="+i);
i--
}
}
}