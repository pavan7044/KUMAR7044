#include<stdio.h>

viod main ()
{
int height,base;

int height,base;

float ans;

printf("enter height and base");

scanf("%d%d",&height,&base);

ans=(1/2)*height*base;

printf("area if triangle is %f",ans);
}