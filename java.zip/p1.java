class P1
{
public static void main(String args[])
{
int a;
a=5;
while(a<=10);
{
System.out.println("   "+a);
a++;
}
}
}






