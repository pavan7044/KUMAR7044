class Five
{
public static void main(String args[])
{
int x,t,i=50;

for(x=1;x<100000;x++)
{
t=x*i;
System.out.print("tables are"+t);


}
}
}






