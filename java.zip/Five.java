class five
{
public static void main(String args[])
{
int x,t,i=5;

for(x=1;x<=2;x++);
{
t=x*i;
System.out.print("tables are"+t);
}
}
}






