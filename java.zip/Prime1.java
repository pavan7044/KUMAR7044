import java.io.*;

public class Prime1
 {
public static void main(String args[])
{
	int hai=100;
	System.out.println("enter the prime numbers between 1 and "+hai);
	for ( int i=0;i<100;i++)
	{
	
	boolean isPrime=true;
		
	
	for(int j=2;j<i;j++)
	{
		if(i%j == 0)
		{
		isPrime=false;
	break;
	}
	}
	if(isPrime)
		System.out.print(i+ " ");
}
 }	
 }