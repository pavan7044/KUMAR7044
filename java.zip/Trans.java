import java.util.Scanner;
import java.io.*;

public class Trans
{
public static void main(String args[])
{
int a,b,m,n;
Scanner sc=new Scanner(System.in);

System.out.println( "enter the rows & columns ");
a=sc.nextInt();
b=sc.nextInt();

int Matrix[][]= new int[m][n];

System.out.println ("enter the matrix values :");

for(a=0;a<m;a++)
	for(b=0;b<n;b++)
		Matrix[a][b] = sc.nextInt();
			int transpose[][] = new int[n][m];
for(a=0;a<m;a++)
{
	for(b=0;b<n;b++)
		transpose[b][a] = Matrix[a][b];

}
System.out.println(" transpose of the matrix :-");

	for(a=0;a<n;a++) 
{
		for(b=0;b<m;b++)
System.out.println(  transpose[a][b]+"\t");
}
}
}


