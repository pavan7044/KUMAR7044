import java.io.*;
import java.util.Scanner;

public class ForDemo2
{

public static void main(String args[])
{
int []b =new int[5];
b[0]=10;
b[1]=20;
b[2]=30;
b[3]=40;
b[4]=50;
for(int i=4;i>=0;i--)
{
System.out.println(" b(i) " + b[i]);
}
}
}
