import java.io.*;
public class Greatest
{
public static void main(String args[])
{
int a=25,b=62,c=44;
for(a>b>c)
{
System.out.println(	