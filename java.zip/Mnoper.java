class Mnoper
{

public static void main(String[] args)

{
 Operations o1=new Operations();
o1.hi();
float f=o1.avg(3,4,7);
System.out.println("\n" +f);
float g=o1.pi();
System.out.println("\n"+g);
}
}