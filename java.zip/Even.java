import java.util.*;
class C1
{
public static void main(string [] args);
int num;
System.out.println("enter a number:");
num = sc.nextInt();
if(num==1)
System.out.println("  MONDAY ");
if(num==2)
System.out.println("  TUESDAY ");
if(num==3)
System.out.println("  WEDNESDAY");
if(num==4)
System.out.println("  THURSDAY");
if(num==5)
System.out.println("  FRIDAY ");
if(num==6)
System.out.println("  SATURDAY ");
if(num==7)
System.out.println("  SATURDAY ");
}