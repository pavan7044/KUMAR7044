class Oldcalc
{ 
int a,b;
	viod input()
{
scanner.sc=new scanner(System.in);
System.out.println("+a+"+"+b+");

}
}