import java.io.*;
import java.util.Scanner;

public class SwitchDemo6
{
public static void main(String args[])
{
int i=0; 
while(i<=50)
{
System.out.println("i="+i);
i++;
}
}
}