package testshop;

@Controller
public class HelloController {
	
	@RequestMapping("/hello")
	 public String hello(@RequestParam(value="name", required=false, defaultValue="World") String name, Model model) {
	  
	   model.addAttribute("name", name);
	   //returns the view name
	   return "helloworld";
	 
	 }
}
